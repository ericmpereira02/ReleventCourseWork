
public abstract class ToppingsDecorator extends Burger{
	
	public abstract String getDescription();
}
