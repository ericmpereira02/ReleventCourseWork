
public class TripleBypass extends Burger {

	public TripleBypass() {
		description = "one and a half pound burger";
	}
	
	@Override
	public double cost() {
		return 8.50;
	}

	
}
