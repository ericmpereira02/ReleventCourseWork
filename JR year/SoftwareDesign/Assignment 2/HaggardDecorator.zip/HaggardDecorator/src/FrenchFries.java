
public class FrenchFries extends ToppingsDecorator{
	Burger burger;
	
	public FrenchFries(Burger burger) {
	this.burger = burger;
	}
	
	@Override
	public String getDescription() {
		return burger.getDescription() + ", french fries";
	}

	@Override
	public double cost() {
		return .75 + burger.cost();
	}
}
