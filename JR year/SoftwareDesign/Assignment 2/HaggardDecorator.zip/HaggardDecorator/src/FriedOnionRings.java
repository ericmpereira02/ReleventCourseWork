
public class FriedOnionRings extends ToppingsDecorator{
	Burger burger;
	
	public FriedOnionRings(Burger burger) {
	this.burger = burger;
	}
	
	@Override
	public String getDescription() {
		return burger.getDescription() + ", fried onion rings";
	}

	@Override
	public double cost() {
		return .75 + burger.cost();
	}

}
