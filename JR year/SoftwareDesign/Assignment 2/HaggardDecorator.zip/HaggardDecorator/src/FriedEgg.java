
public class FriedEgg extends ToppingsDecorator {
	Burger burger;
	
	public FriedEgg(Burger burger) {
		this.burger = burger;
	}
	@Override
	public String getDescription() {
		return burger.getDescription() + ", Fried egg";
	}

	@Override
	public double cost() {
		return .75 + burger.cost();
	}

}
