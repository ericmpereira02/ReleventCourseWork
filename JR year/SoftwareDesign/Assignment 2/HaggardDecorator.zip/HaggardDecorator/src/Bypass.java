
public class Bypass extends Burger{

	public Bypass() {
		description = "half pound burger";
	}
	
	@Override
	public double cost() {
		return 3.50;
	}
	
	

}
