
public class JalapenoPeppers extends ToppingsDecorator {
	Burger burger;
	
	public JalapenoPeppers(Burger burger) {
	this.burger = burger;
	}
	
	@Override
	public String getDescription() {
		return burger.getDescription() + ", Jalapeno Peppers";
	}

	@Override
	public double cost() {
		return burger.cost();
	}
}
