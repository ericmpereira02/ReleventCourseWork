/*
 * Austin Haggard
 * Assignment # 2
 */
public class CoronaryCastle {

	public static void main(String[] args) {
		Burger burger1 = new Bypass();
		System.out.printf("%s $%.2f %n", burger1.getDescription(), burger1.cost());
		
		Burger burger2 = new DoubleBypass();
		burger2 = new Bacon(burger2);
		burger2 = new Cheese(burger2);
		burger2 = new Lettuce(burger2);
		burger2 = new Tomato(burger2);
		burger2 = new Mayonnaise(burger2);
		System.out.printf("%s $%.2f %n", burger2.getDescription(), burger2.cost());
		
		Burger burger3 = new TripleBypass();
		burger3 = new Bacon(burger3);
		burger3 = new Bacon(burger3);
		burger3 = new Cheese(burger3);
		burger3 = new Cheese(burger3);
		burger3 = new FriedEgg(burger3);
		System.out.printf("%s $%.2f %n", burger3.getDescription(), burger3.cost());
		
		Burger burger4 = new QuadrupleBypass();
		burger4 = new Mustard(burger4);
		burger4 = new Onion(burger4);
		burger4= new JalapenoPeppers(burger4);
		System.out.printf("%s $%.2f %n", burger4.getDescription(), burger4.cost());
		
	}
}
