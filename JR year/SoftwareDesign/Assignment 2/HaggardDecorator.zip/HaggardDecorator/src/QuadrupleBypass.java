
public class QuadrupleBypass extends Burger {

	public QuadrupleBypass() {
		description = "two pound burger";
	}

	@Override
	public double cost() {
		return 9.75;
	}
}
