
public class DoubleBypass extends Burger{


	public DoubleBypass() {
		description = "one pound burger";
	}

	@Override
	public double cost() {
		return 6.50;
	}
}
