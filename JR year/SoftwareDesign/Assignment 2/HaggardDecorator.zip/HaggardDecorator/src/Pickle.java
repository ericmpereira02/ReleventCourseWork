
public class Pickle extends ToppingsDecorator {
	Burger burger;
	
	public Pickle(Burger burger) {
	this.burger = burger;
	}
	
	@Override
	public String getDescription() {
		return burger.getDescription() + ", Pickles";
	}

	@Override
	public double cost() {
		return burger.cost();
	}
}
