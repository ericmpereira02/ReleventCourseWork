
public class Mustard extends ToppingsDecorator{
	Burger burger;
	
	public Mustard(Burger burger) {
	this.burger = burger;
	}
	
	@Override
	public String getDescription() {
		return burger.getDescription() + ", Mustard";
	}

	@Override
	public double cost() {
		return burger.cost();
	}
}
