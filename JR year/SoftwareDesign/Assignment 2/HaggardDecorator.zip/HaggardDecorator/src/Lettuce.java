
public class Lettuce extends ToppingsDecorator{
	Burger burger;
	
	public Lettuce(Burger burger) {
	this.burger = burger;
	}
	
	@Override
	public String getDescription() {
		return burger.getDescription() + ", Lettuce";
	}

	@Override
	public double cost() {
		return burger.cost();
	}
}
