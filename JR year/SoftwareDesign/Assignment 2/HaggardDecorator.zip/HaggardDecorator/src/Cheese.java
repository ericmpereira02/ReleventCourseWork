
public class Cheese extends ToppingsDecorator {
	Burger burger;
	public Cheese(Burger burger) {
		this.burger = burger;
	}
	
	@Override
	public String getDescription() {
		return this.burger.getDescription() + ", Cheese";
	}

	@Override
	public double cost() {
		return .50 + this.burger.cost();
	}

}
