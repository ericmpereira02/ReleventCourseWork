
public class Mayonnaise extends ToppingsDecorator {
	Burger burger;
	
	public Mayonnaise(Burger burger) {
	this.burger = burger;
	}
	
	@Override
	public String getDescription() {
		return burger.getDescription() + ", Mayonnaise";
	}

	@Override
	public double cost() {
		return burger.cost();
	}
}
