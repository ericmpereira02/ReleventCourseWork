
public class Bacon extends ToppingsDecorator {
	Burger burger;
	
	public Bacon(Burger burger) {
		this.burger = burger;
	}
	@Override
	public String getDescription() {
		return this.burger.getDescription() + ", Bacon";
	}

	@Override
	public double cost() {
		return 1.00 + this.burger.cost();
	}

}
