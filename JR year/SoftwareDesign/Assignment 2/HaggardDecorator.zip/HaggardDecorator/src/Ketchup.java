
public class Ketchup extends ToppingsDecorator{
	Burger burger;
	
	public Ketchup(Burger burger) {
	this.burger = burger;
	}
	
	@Override
	public String getDescription() {
		return burger.getDescription() + ", Ketchup";
	}

	@Override
	public double cost() {
		return burger.cost();
	}
}
