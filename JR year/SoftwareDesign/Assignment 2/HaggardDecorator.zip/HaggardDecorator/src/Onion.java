
public class Onion extends ToppingsDecorator {
	Burger burger;
	
	public Onion(Burger burger) {
	this.burger = burger;
	}
	
	@Override
	public String getDescription() {
		return burger.getDescription() + ", Onions";
	}

	@Override
	public double cost() {
		return burger.cost();
	}
}
