import java.util.Hashtable;


public class CoronaryCastleMenu implements Menu{
	Hashtable<String, MenuItem> menuItems;
	
	public CoronaryCastleMenu() {
		menuItems = new Hashtable<String, MenuItem>();
		
		addItem("Bypass", "Half pound burger", false, 3.50);
		addItem("Double Bypass", "One pound burger", false, 6.50);
		addItem("Triple Bypass", "One and a half pound burger", false, 8.50);
		addItem("Quadruple Bypass", "Two pound burger", false, 9.75);
		addItem("Bacon", "Topping", false, 1.00);
		addItem("Fried egg", "Topping", true, 0.75);
		addItem("Cheese", "Topping", true, 0.50);
		addItem("Fried onion rings", "Topping served on sandwich", true, 0.75);
		addItem("French Fries", "Topping served on sandwich", true, 0.75);
	}
	
	public void addItem(String name, String description,
            boolean vegetarian, double price) {
		MenuItem menuItem = new MenuItem(name, description, vegetarian, price);
		menuItems.put(name, menuItem);
	}
	
	@Override
	public Iterator createIterator() {
		return new CoronaryCastleMenuIterator(menuItems);
	}
	
	public String toString() {
		return "Coronary Castle Menu";
	}

}
