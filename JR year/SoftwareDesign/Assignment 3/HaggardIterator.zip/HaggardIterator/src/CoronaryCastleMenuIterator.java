import java.util.Enumeration;
import java.util.Hashtable;


public class CoronaryCastleMenuIterator implements Iterator {
	@SuppressWarnings("rawtypes")
	Enumeration items;
	
	public CoronaryCastleMenuIterator(Hashtable<String, MenuItem> menuItems) {
		this.items = menuItems.elements();
		
	}

	@Override
	public boolean hasNext() {
		return items.hasMoreElements();
	}

	@Override
	public Object next() {
		Object object = items.nextElement();
		return object;
	}

}
