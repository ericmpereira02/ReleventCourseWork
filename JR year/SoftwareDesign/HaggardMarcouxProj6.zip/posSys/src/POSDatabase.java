/*
 * Austin Haggard & Alyssa Marcoux
 * Team 1
 * Assignment 6
 */
import java.util.Hashtable;

/**
 * By controller
 * Determines which POS gets selected from collection
 */
public class POSDatabase {
	
	POS pos = new POS();
	
	public POSDatabase() {
	}
	
	public Hashtable<Integer, Course> getCourses(String userID) {
		return pos.studentPrograms.get(userID);	
	}
}
