/*
 * Austin Haggard & Alyssa Marcoux
 * Team 1
 * Assignment 6
 */
import java.util.Scanner;
/**
 * Main system interaction By controller
 */
public class POSSystem {
	static Boolean login = false;
	static BannerAdapter banner;
	static String studentUser;
	public static void main(String[] args) {
		banner = new BannerAdapter();
		login();
		if(login){
			update();
		}
		else{
			System.out.println("Not valid user\nIncorrect username or password");
		}
	}
	
	/**
	 * Determines if user is an admin or not and handles update as neccessary
	 */
	private static void update() {		
		if(banner.isAdmin()){
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			System.out.println("You are an admin!");
			System.out.println("Enter user ID to edit: ");
			String userID = sc.next().toLowerCase();
			if (banner.users.containsKey(userID)) {
				studentUser = userID;
			}
		}
		else{
			System.out.println("You are not an admin!");
		}
		POSController pos = new POSController(studentUser);
		pos.menu();
	}

	/**
	 * Handles login pulls login data from banner
	 */
	public static void login(){
		System.out.println("Username: ");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		studentUser = sc.next().toLowerCase();
		System.out.println("Password: ");
		String pass = sc.next().toLowerCase();
		login = banner.login(studentUser, pass);
	}
}
