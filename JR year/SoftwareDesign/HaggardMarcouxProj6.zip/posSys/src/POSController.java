/*
 * Austin Haggard & Alyssa Marcoux
 * Team 1
 * Assignment 6
 */
import java.util.Hashtable;
import java.util.Scanner;
import java.util.Set;
/**
 * By controller
 *
 */
public class POSController {

	String userID;
	POS pos;
	POSDatabase posDB;
	Hashtable<Course, String> grades;
	/**
	 * Constructor
	 * @param userID: username of program of study being accessed
	 */
	public POSController(String userID) {
		this.userID = userID;
		posDB = new POSDatabase();
		this.grades = BannerAdapter.getGrades(userID);
	}
	
	/**
	 * Gets grade information taken from banner and matches it to the class
	 */
	public void getCourses() {
		Hashtable<Integer, Course> classes = posDB.getCourses(this.userID);
		Set<Integer> keys = classes.keySet();
		Set<Course>  gradeKeys = grades.keySet();
		for (Integer key: keys) {
			System.out.printf(key + ": " + classes.get(key).courseName);
			for(Course gradeKey: gradeKeys){
				if(gradeKey.sameClass(classes.get(key).courseName)){
					String grade = grades.get(gradeKey);
					System.out.printf(" Grade: " + grade);
					break;
				}
			}
			System.out.println();
		}
	}
	
	/**
	 * Updates POS saved in collection of POS's
	 */
	public void updatePOS() {
		int key;
		String newClass, temp;
		boolean req = false, elect = false;
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the semester you want to edit: ");
		temp = sc.nextLine();
		key = Integer.parseInt(temp);
		System.out.printf("Current class is %s, what would you like to rename it too: \n", posDB.getCourses(this.userID).get(key).courseName);
		newClass = sc.nextLine();
		System.out.println("is this class required? True or False: ");
		temp = sc.next();
		if (temp.toLowerCase().equals("true"))
			req = true;
		System.out.println("is this class an elective? True or False: ");
		temp = sc.next();
		if (temp.toLowerCase().equals("true"))
			elect = true;
		Course course = new Course(req, elect, newClass);
		posDB.getCourses(this.userID).put(key, course);
	}
	
	/**
	 * Menu of options view, update, or exit
	 */
	public void menu(){
		System.out.printf("1: view courses %n2: edit courses %n3: exit%n");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		while(choice != 3){
			switch(choice) {
			case 1: this.getCourses();
				break;
			case 2: this.updatePOS();
				break;
			case 3: System.out.println("exit");
				break;
			default: System.out.println("Invalid choice");
				break;
			}
			System.out.printf("1: view courses %n2: edit courses %n3: exit%n");
			choice = sc.nextInt();
		}
	}
}
