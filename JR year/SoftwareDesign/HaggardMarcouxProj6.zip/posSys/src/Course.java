/*
 * Austin Haggard & Alyssa Marcoux
 * Team 1
 * Assignment 6
 */
public class Course {
/**
 * 
 */
	boolean required = false;
	boolean elective = false;
	String courseName;
	public Course(boolean req, boolean elect, String name) {
		required = req;
		elective = elect;
		courseName = name;
	}
	public String getCourse(){
		return courseName;
	}
	public boolean getRequired(){
		return required;
	}
	public boolean getElective(){
		return elective;
	}
	public boolean sameClass(String name){
		if (name.equals(this.getCourse())){
			return true;
	}
		return false;
	}
}