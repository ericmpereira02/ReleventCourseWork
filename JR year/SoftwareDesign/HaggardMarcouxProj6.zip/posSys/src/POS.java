/*
 * Austin Haggard & Alyssa Marcoux
 * Team 1
 * Assignment 6
 */
import java.util.Hashtable;

public class POS {
	Hashtable<String, Hashtable<Integer, Course>> studentPrograms = new Hashtable<String, Hashtable<Integer, Course>>();
	Hashtable<Integer, Course> classes;
	/**
	 * Collection of Programs of study
	 * Information Expert
	 */
	public POS(){
	 posDb();
	}
	public void posDb(){
		classes = new Hashtable<Integer, Course>();
		
		Course mth101 = new Course(true, false, "mth101");
		classes.put(101, mth101);
		
		Course phy101 = new Course(true, true, "phy101");
		classes.put(102, phy101);
		
		Course com101 = new Course(true, false, "com101");
		classes.put(201, com101);
		
		Course mth102 = new Course(true, false, "mth102");
		classes.put(202, mth102);
		
		Course mth201 = new Course(true, false, "mth201");
		classes.put(301, mth201);
		
		Course hum201 = new Course(true, true, "hum201");
		classes.put(302, hum201);
		
		Course com202 = new Course(true, false, "com202");
		classes.put(401, com202);
		
		Course cse402 = new Course(true, false, "cse402");
		classes.put(402, cse402);
		studentPrograms.put("amarcoux2013", classes);
		
		classes = new Hashtable<Integer, Course>();
		Course cse101 = new Course(true, false, "cse101");
		classes.put(101, cse101);
		
		Course cse102 = new Course(true, false, "cse102");
		classes.put(102, cse102);
		
		Course cse201 = new Course(true, false, "cse201");
		classes.put(201, cse201);
		
		Course hum = new Course(true, true, "humanities elective");
		classes.put(202, hum);
		
		Course cse301 = new Course(true, false, "cse303");
		classes.put(301, cse301);
		
		Course cse302 = new Course(true, false, "cse302");
		classes.put(302, cse302);
		
		Course cse401 = new Course(true, false, "cse401");
		classes.put(401, cse401);
		
		Course phy201 = new Course(true, true, "Phy201");
		classes.put(402, phy201);
		studentPrograms.put("test2013", classes);
	}
	
	public void grades(String Username){
		BannerAdapter.getGrades(Username);
	}
}
