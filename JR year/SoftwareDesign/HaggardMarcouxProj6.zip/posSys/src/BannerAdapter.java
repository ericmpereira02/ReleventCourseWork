/*
 * Austin Haggard & Alyssa Marcoux
 * Team 1
 * Assignment 6
 */
import java.util.ArrayList;
import java.util.Hashtable;

/**
 * Adapter
 */
public class BannerAdapter {
	@SuppressWarnings("rawtypes")
	Hashtable<String, ArrayList> users = new Hashtable<String, ArrayList>();
	String admin;
	
	static Hashtable<String, Hashtable<Course, String>> studentGrades = new Hashtable<String, Hashtable<Course, String>>();
	Hashtable<Course, String> grades;
	
public BannerAdapter() {	
	loginDB();
	gradesDB();
	}

private void gradesDB() {
	grades = new Hashtable<Course, String>();
	
	Course mth101 = new Course(true, false, "mth101");
	grades.put(mth101, "B");
	
	Course phy101 = new Course(true, true, "phy101");
	grades.put(phy101, "C");
	
	Course mth102 = new Course(true, false, "mth102");
	grades.put(mth102, "A");
	
	Course com101 = new Course(true, false, "com101");
	grades.put(com101,"B");
	
	studentGrades.put("amarcoux2013", grades);
	
	grades = new Hashtable<Course, String>();
	
	Course cse101 = new Course(true, false, "cse101");
	grades.put(cse101, "A");
	
	Course cse102 = new Course(true, false, "cse102");
	grades.put(cse102, "A");
	
	Course cse201 = new Course(true, false, "cse201");
	grades.put(cse201, "A");
	studentGrades.put("test2013", grades);
}

private void loginDB() {
	ArrayList<String> passAndAdmin = new ArrayList<String>();
	passAndAdmin.add("hello");
	passAndAdmin.add("false");
		users.put("amarcoux2013", passAndAdmin);
	
	passAndAdmin = new ArrayList<String>();
	passAndAdmin.add("goodbye");
	passAndAdmin.add("true");
		users.put("ahaggard2013", passAndAdmin);
	
	passAndAdmin = new ArrayList<String>();
	passAndAdmin.add("yes");
	passAndAdmin.add("false");
		users.put("test2013", passAndAdmin);	
}

public boolean login(String user, String pass){
	if(users.containsKey(user) && pass.equals(users.get(user).get(0))){
		admin = user;
		return true;
	}
	return false;
}

public boolean isAdmin() {
	if(users.get(admin).get(1).equals("true")){
		return true;
	}
	return false;
}

public static Hashtable<Course,String> getGrades(String Username){
	return studentGrades.get(Username);
}

}
