
public class DimLightsCommand implements Command {
	Light light;
	int level;
	public DimLightsCommand(Light light, int level) {
		this.light = light;
		this.level = level;
	}
	@Override
	public void execute() {
		light.dim(level);
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
