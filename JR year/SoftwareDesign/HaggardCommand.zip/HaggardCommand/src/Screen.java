
public class Screen {
	
	public Screen() {
		// TODO Auto-generated constructor stub
	}
	
	public void drop() {
		System.out.println("Screen is dropped");
	}
	
	public void raise() {
		System.out.println("Screen is raised");
	}
}
