
public class RaiseScreenCommand implements Command {
	Screen screen;
	
	public RaiseScreenCommand(Screen Screen) {
		this.screen = Screen;
	}
	@Override
	public void execute() {
		screen.raise();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
