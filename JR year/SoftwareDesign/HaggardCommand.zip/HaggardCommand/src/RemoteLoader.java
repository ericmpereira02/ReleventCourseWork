// Austin Haggard Assignment 4

public class RemoteLoader {

	public static void main(String[] args) {

		RemoteControl remoteControl = new RemoteControl();

		Light light = new Light("Living Room");
		Projector projector = new Projector();
		Screen screen = new Screen();
 
		DimLightsCommand dimLights = new DimLightsCommand(light, 50);
		FullLightingCommand fullLights = new FullLightingCommand(light);
		ProjectorOffCommand projectorOff = new ProjectorOffCommand(projector);
		ProjectorOnCommand projectorOn = new ProjectorOnCommand(projector);
		DropScreenCommand dropScreen = new DropScreenCommand(screen);
		RaiseScreenCommand raiseScreen = new RaiseScreenCommand(screen);

		Command[] start = {dimLights, dropScreen, projectorOn};
		Command[] end = { fullLights, 	raiseScreen, projectorOff};
  
		MacroCommand startClass = new MacroCommand(start);
		MacroCommand endClass = new MacroCommand(end);
 
		remoteControl.setCommand(0, startClass, endClass);
  
		System.out.println(remoteControl);
		System.out.println("--- Pushing Macro On---");
		remoteControl.onButtonWasPushed(0);
		System.out.println("--- Pushing Macro Off---");
		remoteControl.offButtonWasPushed(0);
	}
}
