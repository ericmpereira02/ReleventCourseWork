
public class ProjectorOnCommand implements Command {
	Projector projector;
	
	public ProjectorOnCommand(Projector projector) {
		this.projector = projector;
	}
	
	@Override
	public void execute() {
		projector.on();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
