
public class DropScreenCommand implements Command {
	Screen screen;
	
	public DropScreenCommand(Screen Screen) {
		this.screen = Screen;
	}
	
	@Override
	public void execute() {
		screen.drop();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
