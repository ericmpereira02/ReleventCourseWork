
public class FullLightingCommand implements Command{
	Light light;
	
	public FullLightingCommand(Light light) {
		this.light = light;
	}
	
	@Override
	public void execute() {
		light.fullLighting();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
