
public class ProjectorOffCommand implements Command {
	Projector projector;
	
	public ProjectorOffCommand(Projector projector) {
		this.projector = projector;
	}
	@Override
	public void execute() {
		projector.off();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

}
