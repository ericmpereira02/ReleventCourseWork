// Austin Haggard
// Assignment # 1

public class ServiceProvider {
	public static ServiceProvider instance = null;
	
	public ServiceProvider() {
		// TODO Auto-generated constructor stub
	}
	
	public static synchronized ServiceProvider getInstance() {
		if (instance == null) {
			instance = new ServiceProvider();
			System.out.println("Constructing ServiceProvider");
		} else System.out.println("ServiceProvider already exists");
		return instance;
	}
}