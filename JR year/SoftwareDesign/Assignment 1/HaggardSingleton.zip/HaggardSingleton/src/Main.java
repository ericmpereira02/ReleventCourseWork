// Austin Haggard
// Assignment # 1

public class Main {

	public static void main(String[] args) {
		ServiceProvider.getInstance();
		ServiceProvider.getInstance();
		ServiceProvider.getInstance();
	}
}
