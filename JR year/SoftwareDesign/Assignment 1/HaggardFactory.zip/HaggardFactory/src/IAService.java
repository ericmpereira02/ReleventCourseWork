/**
 * 
 * @author Austin haggard
 * Assignment # 1 Factory
 */

interface IAService {

	void ProvideService();
}
