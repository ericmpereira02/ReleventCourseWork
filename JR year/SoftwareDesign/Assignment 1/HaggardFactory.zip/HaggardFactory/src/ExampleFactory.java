/**
 * 
 * @author Austin haggard
 * Assignment # 1 Factory
 */

public class ExampleFactory {
	public static ExampleFactory instance = null;
	public ExampleFactory() {
		// TODO Auto-generated constructor stub
	}
	
	public static synchronized ExampleFactory getInstance() {
		if (instance == null) {
			instance = new ExampleFactory();
			System.out.println("Constructing Example Factory");
		} else System.out.println("Example Factory already exists");
		return instance;
	}

	public static AService getService() {
		return new AService();
	}
}
