/**
 * 
 * @author Austin haggard
 * Assignment # 1 Factory
 */
public class AService implements IAService{

	@Override
	public void ProvideService() {
		System.out.println("I’m now providing the service for MyController");
	}

}
