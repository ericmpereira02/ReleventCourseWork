/**
 * 
 * @author Austin haggard
 * Assignment # 1 Factory
 */

public class MyController {

	public static void main(String[] args) {
		ExampleFactory.getInstance();
		AService service = ExampleFactory.getService();
		service.ProvideService();
	}
}
